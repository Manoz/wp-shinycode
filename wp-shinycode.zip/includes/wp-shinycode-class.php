<?php
/**
 * Plugin core class.
 * @since       1.0.0
 * @author      Kevin Legrand <manoz@outlook.com>
 * @license     GPL-2.0+
 * @copyright   2014 Kevin Legrand
 */

